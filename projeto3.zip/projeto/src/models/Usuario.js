// src/models/Avaliacao.js
const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
    nome: String,
    userName: String,
    email: String,
    telefone: String,
    nif: String,
    password: String,
    avaliacoes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Avaliacao' }],
    favoritos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    reservas: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: Boolean
});
module.exports = mongoose.model('Usuario', usuarioSchema);
