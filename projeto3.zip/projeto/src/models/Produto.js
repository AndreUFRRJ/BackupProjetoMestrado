//src/ models/Produto.js
const mongoose = require('mongoose');

const produtoSchema = new mongoose.Schema({
    nome: String,
    categoria: String,
    vendedor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' },
    descricao: String,
    precoOriginal: Number,
    precoPromocional: Number,
    stock: Number,
    clientesInteressados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Cliente' }],
    ativo: Boolean,
    destacado: Boolean
});
module.exports = mongoose.model('Produto', produtoSchema);