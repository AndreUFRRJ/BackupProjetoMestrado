// src/routes/usuarioRoutes.js
const express = require('express');
const Usuario = require('../models/Usuario.js');

const router = express.Router();

//GET
router.get("/", async (req, res) => {
    try {
        const usuario = await Usuario.find();
        res.status(200).send(usuario);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).send('Erro no servidor');
    }
});
//POST

router.post("/", async (req, res) => {
    try {
        const user = new Usuario({
            nome: req.body.nome,
            userName: req.body.userName,
            email: req.body.email,
            telefone: req.body.telefone,
            nif: req.body.nif,
            password: req.body.password,
            avaliacoes: [],
            favoritos: [],
            reservas: [],
            banido: false
        });
        await user.save();
        res.status(201).send(user);
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).send('Erro no servidor');
    }
});


//DELETE


router.delete("/:id", async (req, res) => {
    try {
        const usuario = await Usuario.findByIdAndDelete(req.params.id);
        if (!usuario) {
            return res.status(404).send('Usuario não encontrado');
        }
        res.status(200).send('Usuario removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover usuario:', error);
        res.status(500).send('Erro no servidor');
    }
});

//UPDATE
router.put("/:id",async(req,res)=>{
    const usuario=await Usuario.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        userName: req.body.userName,
        email: req.body.email,
        telefone: req.body.telefone,
        nif: req.body.nif,
        password: req.body.password,
        avaliacoes: [],
        favoritos: [],
        reservas: [],
        banido: req.body.banido            
    },{new:true} );
    res.status(200).send(usuario);
});
module.exports = router;
