// src/routes/avaliacaoRoutes.js
const express = require('express');
const Avaliacao = require('../models/Avaliacao.js');

const router = express.Router();
//get
router.get("/", async (req, res) => {
    try {
        const avaliacao = await Avaliacao.find();
        res.status(200).send(avaliacao);
    } catch (error) {
        console.error('Erro ao buscar avaliações:', error);
        res.status(500).send('Erro no servidor');
    }
});
//POST

router.post("/", async (req, res) => {
    try {
        const avaliacao = new Avaliacao({
            vendedor: req.body.idVendedor,
            cliente: req.body.idCliente,
            nota: req.body.nota
        });
        await avaliacao.save();
        res.status(201).send(avaliacao);
    } catch (error) {
        console.error('Erro ao criar avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
});

//Delete
router.delete("/:id", async (req, res) => {
    try {
        const avaliacao = await Avaliacao.findByIdAndDelete(req.params.id);
        if (!avaliacao) {
            return res.status(404).send('Avaliação não encontrado');
        }
        res.status(200).send('Avaliação removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover avaliacao:', error);
        res.status(500).send('Erro no servidor');
    }
});

//UPDATE
router.put("/:id",async(req,res)=>{
    const avaliacao=await Avaliacao.findByIdAndUpdate(req.params.id,{
        vendedor:req.body.idVendedor,
        cliente: req.body.idCliente,
        nota: req.body.nota
            
    },{new:true} );
    res.status(200).send(avaliacao);
});

module.exports = router;
