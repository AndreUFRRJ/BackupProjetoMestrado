// src/routes/produtoRoutes.js
const express = require('express');
const Produto = require('../models/Produto.js');

const router = express.Router();

//GET
router.get("/", async (req, res) => {
    try {
        const produto = await Produto.find();
        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        res.status(500).send('Erro no servidor');
    }
});


//POST
router.post("/", async (req, res) => {
    try {
        const produto = new Produto({
            nome: req.body.nome,
            categoria: req.body.categoria,
            vendedor: '6758aa9f1c8dbca30c857ac8', // Substitua por um ID válido
            descricao: req.body.descricao,
            precoOriginal: req.body.precoOriginal,
            precoPromocional: req.body.precoPromocional,
            stock: req.body.stock,
            clientesInteressados: [],
            ativo: true,
            destacado: false
        });
        await produto.save();
        res.status(201).send(produto);
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).send('Erro no servidor');
    }
});

//DELETE
router.delete("/:id", async (req, res) => {
    try {
        const produto = await Produto.findByIdAndDelete(req.params.id);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }
        res.status(200).send('Produto removido com sucesso');
    } catch (error) {
        console.error('Produto ao remover admin:', error);
        res.status(500).send('Erro no servidor');
    }
});

//UPDATE
router.put("/:id",async(req,res)=>{
    const produto=await Produto.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        categoria: req.body.categoria,
        vendedor: req.body.idVendedor,
        descricao: req.body.descricao,
        precoOriginal: req.body.precoOriginal,
        precoPromocional: req.body.precoPromocional,
        stock: req.body.stock,
        clientesInteressados: [],
        ativo: req.body.ativo,
        destacado: req.body.destacado
            
    },{new:true} );
    res.status(200).send(produto);

});



module.exports = router;
