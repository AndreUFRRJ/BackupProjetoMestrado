// src/models/Avaliacao.js
const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: [true, 'O nome é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O nome não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    userName: {
        type: String,
        required: [true, "Sem Nickname"],
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O UserName não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    email: { 
        type: String,
        required: [true, 'O email é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O Email não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    telefone: {
        type:String
    },
    nif: {
        type: String,
        required: [true, 'O NIF é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length === 9 && /^\d{9}$/.test(v.trim());
            },
            message: 'numero do nif invalido ou ja utilizado' // Mensagem de erro personalizada
        }
    },
    password: {
        type: String,
        required: [true, 'uma senha é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 6;
            },
            message: 'Senha muito curta' // Mensagem de erro personalizada
        }
    },
    avaliacoes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Avaliacao' }],
    favoritos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    reservas: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: {
        type:Boolean,
        default:false
    }
});
module.exports = mongoose.model('Usuario', usuarioSchema);
