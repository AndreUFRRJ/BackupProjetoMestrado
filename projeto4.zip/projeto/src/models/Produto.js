// src/models/Produto.js
const mongoose = require('mongoose');

const produtoSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: [true, 'O nome é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O nome não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    categoria: {
        type: String,
        required: true // Adicionando a obrigatoriedade
    },
    vendedor: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Vendedor',
        required: true // Adicionando a obrigatoriedade
    },
    descricao: {
        type: String,
        required: true // Adicionando a obrigatoriedade
    },
    precoOriginal: {
        type: Number,
        min: 0 // Valor mínimo de 0
    },
    precoPromocional: {
        type: Number,
        min: 0 // Valor mínimo de 0
    },
    stock: {
        type: Number,
        min: 0 // Valor mínimo de 0
    },
    clientesInteressados: [{ 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Cliente' 
    }],
    ativo: {
        type: Boolean,
        default: true // Valor padrão como verdadeiro
    },
    destacado: {
        type: Boolean,
        default: false // Valor padrão como falso
    }
});

module.exports = mongoose.model('Produto', produtoSchema);
