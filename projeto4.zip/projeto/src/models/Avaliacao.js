//src/ models/Avaliacao.js
const mongoose = require('mongoose');

const avaliacaoSchema = new mongoose.Schema({
    vendedor: {
         type: mongoose.Schema.Types.ObjectId, 
         ref: 'Vendedor',
         required:[true,"erro... Vendedor deve ser Definido"] 
        },
    cliente: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Cliente', 
        required:[true,"erro... Cliente deve ser Definido"]
    },
    nota: {
        type:Number,
        min:[0,"erro ao computar a nota"],
        max:[5,"erro ao computar a nota"]
    }
});

module.exports = mongoose.model('Avaliacao', avaliacaoSchema);