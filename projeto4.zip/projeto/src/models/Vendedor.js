// src/models/Vendedor.js
const mongoose = require('mongoose');

const vendedorSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: [true, 'O Nome é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O nome não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    email: {
        type: String,
        required: [true, 'O email é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O Email não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    endereco: {
        type: String,
        required: [true, 'O endereço é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O endereço não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    avaliacao: {
        type:Number,
        default:0
    },
    password: {
        type: String,
        required: [true, 'uma senha é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 6;
            },
            message: 'Senha muito curta' // Mensagem de erro personalizada
        }
    },
    produtos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: {
        type:Boolean,
        default:false
    }
});
module.exports = mongoose.model('Vendedor', vendedorSchema);