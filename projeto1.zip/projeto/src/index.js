const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());
const port = 3000;

mongoose.connect('mongodb://127.0.0.1:27017/PWA');

// Modelos
const Usuario = mongoose.model('Usuario', {
    nome: String,
    userName: String,
    email: String,
    telefone: String,
    nif: String,
    password: String,
    avaliacoes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Avaliacao' }],
    favoritos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    reservas: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: Boolean
});

const Produto = mongoose.model('Produto', {
    nome: String,
    categoria: String,
    vendedor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' },
    descricao: String,
    precoOriginal: Number,
    precoPromocional: Number,
    stock: Number,
    clientesInteressados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Cliente' }],
    ativo: Boolean,
    destacado: Boolean
});

const Admin = mongoose.model('Admin', {
    nome: String,
    email: String,
    produtosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    usuariosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Cliente' }],
    vendedoresBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' }]
});

const Vendedor = mongoose.model('Vendedor', {
    nome: String,
    email: String,
    endereco: String,
    avaliacao: Number,
    password: String,
    produtos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: Boolean
});

const Avaliacao = mongoose.model('Avaliacao', {
    vendedor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' },
    cliente: { type: mongoose.Schema.Types.ObjectId, ref: 'Cliente' },
    nota: Number
});

// Iniciar o servidor
app.listen(port, () => {
    console.log("App rodando...");
});

// GET
app.get("/", (req, res) => {
    res.send("Olá, esta é a página teste.");
});

app.get("/admin", async (req, res) => {
    try {
        const admin = await Admin.find();
        res.status(200).send(admin);
    } catch (error) {
        console.error('Erro ao buscar administradores:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.get("/usuario", async (req, res) => {
    try {
        const usuario = await Usuario.find();
        res.status(200).send(usuario);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.get("/vendedor", async (req, res) => {
    try {
        const vendedor = await Vendedor.find();
        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao buscar vendedores:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.get("/produto", async (req, res) => {
    try {
        const produto = await Produto.find();
        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.get("/avaliacao", async (req, res) => {
    try {
        const avaliacao = await Avaliacao.find();
        res.status(200).send(avaliacao);
    } catch (error) {
        console.error('Erro ao buscar avaliações:', error);
        res.status(500).send('Erro no servidor');
    }
});

// POST
app.post("/vendedor", async (req, res) => {
    try {
        const vendedor = new Vendedor({
            nome: req.body.nome,
            email: req.body.email,
            endereco: req.body.endereco,
            avaliacao: 0,
            password: req.body.password,
            produtos: []
        });
        await vendedor.save();
        res.status(201).send(vendedor);
    } catch (error) {
        console.error('Erro ao criar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.post("/admin", async (req, res) => {
    try {
        const admin = new Admin({
            nome: req.body.nome,
            email: req.body.email,
            produtosBloqueados: [],
            usuariosBloqueados: [],
            vendedoresBloqueados: []
        });
        await admin.save();
        res.status(201).send(admin);
    } catch (error) {
        console.error('Erro ao criar admin:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.post("/usuario", async (req, res) => {
    try {
        const user = new Usuario({
            nome: req.body.nome,
            userName: req.body.userName,
            email: req.body.email,
            telefone: req.body.telefone,
            nif: req.body.nif,
            password: req.body.password,
            avaliacoes: [],
            favoritos: [],
            reservas: [],
            banido: false
        });
        await user.save();
        res.status(201).send(user);
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.post("/produto", async (req, res) => {
    try {
        const produto = new Produto({
            nome: req.body.nome,
            categoria: req.body.categoria,
            vendedor: '6758aa9f1c8dbca30c857ac8', // Substitua por um ID válido
            descricao: req.body.descricao,
            precoOriginal: req.body.precoOriginal,
            precoPromocional: req.body.precoPromocional,
            stock: req.body.stock,
            clientesInteressados: [],
            ativo: true,
            destacado: false
        });
        await produto.save();
        res.status(201).send(produto);
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.post("/avaliacao", async (req, res) => {
    try {
        const avaliacao = new Avaliacao({
            vendedor: req.body.idVendedor,
            cliente: req.body.idCliente,
            nota: req.body.nota
        });
        await avaliacao.save();
        res.status(201).send(avaliacao);
    } catch (error) {
        console.error('Erro ao criar avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
});

// Deletar
app.delete("/admin/:id", async (req, res) => {
    try {
        const admin = await Admin.findByIdAndDelete(req.params.id);
        if (!admin) {
            return res.status(404).send('Admin não encontrado');
        }
        res.status(200).send('Admin removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover admin:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.delete("/avaliacao/:id", async (req, res) => {
    try {
        const avaliacao = await Avaliacao.findByIdAndDelete(req.params.id);
        if (!avaliacao) {
            return res.status(404).send('Avaliação não encontrado');
        }
        res.status(200).send('Avaliação removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover avaliacao:', error);
        res.status(500).send('Erro no servidor');
    }
});
app.delete("/produto/:id", async (req, res) => {
    try {
        const produto = await Produto.findByIdAndDelete(req.params.id);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }
        res.status(200).send('Produto removido com sucesso');
    } catch (error) {
        console.error('Produto ao remover admin:', error);
        res.status(500).send('Erro no servidor');
    }
});
app.delete("/usuario/:id", async (req, res) => {
    try {
        const usuario = await Usuario.findByIdAndDelete(req.params.id);
        if (!usuario) {
            return res.status(404).send('Usuario não encontrado');
        }
        res.status(200).send('Usuario removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover usuario:', error);
        res.status(500).send('Erro no servidor');
    }
});

app.delete("/vendedor/:id", async (req, res) => {
    try {
        const vendedor = await Vendedor.findByIdAndDelete(req.params.id);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }
        res.status(200).send('Vendedor removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
});


//update
app.put("/admin/:id",async(req,res)=>{
    const admin=await Admin.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        email: req.body.email,
        produtosBloqueados: [],
        usuariosBloqueados: [],
        vendedoresBloqueados: []            
    },{new:true} )
});
app.put("/usuario/:id",async(req,res)=>{
    const usuario=await Usuario.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        userName: req.body.userName,
        email: req.body.email,
        telefone: req.body.telefone,
        nif: req.body.nif,
        password: req.body.password,
        avaliacoes: [],
        favoritos: [],
        reservas: [],
        banido: req.body.banido            
    },{new:true} )
});

app.put("/produto/:id",async(req,res)=>{
    const produto=await Produto.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        categoria: req.body.categoria,
        vendedor: req.body.idVendedor,
        descricao: req.body.descricao,
        precoOriginal: req.body.precoOriginal,
        precoPromocional: req.body.precoPromocional,
        stock: req.body.stock,
        clientesInteressados: [],
        ativo: req.body.ativo,
        destacado: req.body.destacado
            
    },{new:true} )
});

app.put("/vendedor/:id",async(req,res)=>{
    const vendedor=await Vendedor.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        email: req.body.email,
        endereco: req.body.endereco,
        avaliacao: req.body.avaliacao,
        password: req.body.password,
        produtos: [],
        banido: req.body.banido
            
    },{new:true} )
});
app.put("/avaliacao/:id",async(req,res)=>{
    const avaliacao=await Avaliacao.findByIdAndUpdate(req.params.id,{
        vendedor:req.body.idVendedor,
        cliente: req.body.idCliente,
        nota: req.body.nota
            
    },{new:true} )
});

