//src/ models/Admin.js
const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: [true, 'O nome é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O nome não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    email: {
        type: String,
        required: [true, 'O email é obrigatório'], // Validação para ser obrigatório
        trim: true, // Remove espaços em branco no início e no final
        validate: {
            validator: function(v) {
                return v && v.trim().length > 0; // Verifica se não é vazio
            },
            message: 'O nome não pode ser vazio' // Mensagem de erro personalizada
        }
    },
    produtosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    usuariosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' }],
    vendedoresBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' }]
});

module.exports = mongoose.model('Admin', adminSchema);