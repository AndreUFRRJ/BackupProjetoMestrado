//src/models/Produto
const mongoose = require('mongoose');

const produtoSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: [true, 'O nome do produto é obrigatório'],
        trim: true
    },
    categoria: {
        type: String,
        required: [true, 'A categoria é obrigatória'],
        trim: true
    },
    vendedor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Vendedor',
        required: [true, 'O vendedor é obrigatório']
    },
    descricao: {
        type: String,
        required: [true, 'A descrição é obrigatória'],
        trim: true
    },
    precoOriginal: {
        type: Number,
        required: [true, 'O preço original é obrigatório']
    },
    precoPromocional: {
        type: Number,
        default: 0
    },
    stock: {
        type: Number,
        required: [true, 'O estoque é obrigatório'],
        default: 0
    },
    clientesInteressados: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Cliente'
    }],
    ativo: {
        type: Boolean,
        default: true
    },
    destacado: {
        type: Boolean,
        default: false
    }
});

// Previne a sobreposição do modelo
const Produto = mongoose.models.Produto || mongoose.model('Produto', produtoSchema);

module.exports = Produto;
