//src/controllers/adminController
const Admin = require('../models/Admin');
const Produto = require('../models/Produto');
const Vendedor = require('../models/Vendedor');
const Usuario = require('../models/Usuario');

exports.getAllAdmins = async (req, res) => {
    try {
        const admins = await Admin.find();
        res.status(200).send(admins);
    } catch (error) {
        console.error('Erro ao buscar administradores:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createAdmin = async (req, res) => {
    try {
        const admin = new Admin({
            nome: req.body.nome,
            email: req.body.email,
            produtosBloqueados: [],
            usuariosBloqueados: [],
            vendedoresBloqueados: []
        });
        await admin.save();
        res.status(201).send(admin);
    } catch (error) {
        console.error('Erro ao criar admin:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteAdmin = async (req, res) => {
    try {
        const admin = await Admin.findByIdAndDelete(req.params.id);
        if (!admin) {
            return res.status(404).send('Admin não encontrado');
        }
        res.status(200).send('Admin removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover admin:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateAdmin = async (req, res) => {
    const admin = await Admin.findByIdAndUpdate(req.params.id, {
        nome: req.body.nome,
        email: req.body.email,
        produtosBloqueados: [],
        usuariosBloqueados: [],
        vendedoresBloqueados: []
    }, { new: true });
    
    res.status(200).send(admin);
};

exports.banirUsuario = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const usuario = await Usuario.findById(req.body.id);
        if (!usuario) {
            return res.status(404).send({ message: "Usuário não encontrado" });
        }

        // Banindo o usuário
        usuario.banido = true;
        await usuario.save(); // Salvar as alterações no usuário

        // Adicionando o usuário à lista de bloqueados do administrador
        admin.usuariosBloqueados.push(usuario);
        await admin.save(); // Salvar as alterações no administrador

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir usuário" }); // Retornar um erro genérico
    }
};

exports.banirVendedor = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const vendedor = await Vendedor.findById(req.body.id);
        if (!vendedor) {
            return res.status(404).send({ message: "Vendedor não encontrado" });
        }

        // Banindo o Vendedor
        vendedor.banido = true;
        await vendedor.save(); // Salvar as alterações no vendedor

        // Adicionando o vendedor à lista de bloqueados do administrador
        admin.vendedoresBloqueados.push(vendedor);
        await admin.save(); // Salvar as alterações no administrador

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir vendedor" }); // Retornar um erro genérico
    }
};

exports.banirProduto = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const produto = await Produto.findById(req.body.id);
        if (!produto) {
            return res.status(404).send({ message: "Produto não encontrado" });
        }

        // Banindo o produto
        produto.ativo = false;
        await produto.save(); // Salvar as alterações no produto

        // Adicionando o produto à lista de bloqueados do administrador
        admin.produtosBloqueados.push(produto);
        await admin.save(); // Salvar as alterações no administrador

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir produto" }); // Retornar um erro genérico
    }
};

exports.liberarUsuario = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const usuario = await Usuario.findById(req.body.id);
        if (!usuario) {
            return res.status(404).send({ message: "Usuário não encontrado" });
        }

        // Banindo o usuário
        usuario.banido = false;
        await usuario.save(); // Salvar as alterações no usuário

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir usuário" }); // Retornar um erro genérico
    }
};

exports.liberarVendedor = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const vendedor = await Vendedor.findById(req.body.id);
        if (!vendedor) {
            return res.status(404).send({ message: "Vendedor não encontrado" });
        }

        // Banindo o Vendedor
        vendedor.banido = false;
        await vendedor.save(); // Salvar as alterações no vendedor

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir vendedor" }); // Retornar um erro genérico
    }
};

exports.liberarProduto = async (req, res) => {
    try {
        const admin = await Admin.findById(req.params.id);
        if (!admin) {
            return res.status(404).send({ message: "Admin não encontrado" });
        }

        const produto = await Produto.findById(req.body.id);
        if (!produto) {
            return res.status(404).send({ message: "Produto não encontrado" });
        }

        // Banindo o produto
        produto.ativo = true;
        await produto.save(); // Salvar as alterações no produto

        res.status(200).send(admin); // Retornar o administrador atualizado
    } catch (error) {
        console.error(error); // Logar o erro
        res.status(500).send({ message: "Erro ao banir produto" }); // Retornar um erro genérico
    }
};

