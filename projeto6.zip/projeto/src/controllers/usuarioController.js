//src/controllers/usuarioController
const Usuario = require('../models/Usuario');
const Produto = require('../models/Produto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.getAllUsuarios = async (req, res) => {
    try {
        const usuarios = await Usuario.find();
        res.status(200).send(usuarios);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.getUsuarioById = async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.body.id);
        res.status(200).send(usuario);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.getFavoritos = async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        const favoritos = await Produto.find({ '_id': { $in: usuario.favoritos } }); // Busca produtos favoritos
        res.status(200).send(favoritos);
    } catch (error) {
        console.error('Erro ao buscar favoritos:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.getReservas = async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        const reservas = await Produto.find({ '_id': { $in: usuario.reservas } }); // Busca produtos reservados
        res.status(200).send(reservas);
    } catch (error) {
        console.error('Erro ao buscar reservas:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.addReserva = async (req, res) => {
    try {
        const produto = await Produto.findById(req.body.idProduto);
        if (!produto) {
            return res.status(404).send('Produto não encontrado ou esgotado');
        }
        if (produto.stock<=0 || produto.ativo===false) {
            produto.strock=0;
            produto.ativo=false;
            await produto.save();
            return res.status(404).send('Produto esgotado');
        }

        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Verifica se o produto já está reservado
        if (usuario.reservas.includes(produto._id)) {
            return res.status(400).send('Produto já reservado');
        }

        usuario.reservas.push(produto._id); // Adiciona o ID do produto
        produto.stock--;
        await produto.save();
        await usuario.save(); // Salva as alterações

        res.status(200).send(usuario.reservas); // Retorna as reservas atualizadas
    } catch (error) {
        console.error('Erro ao adicionar reserva:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.addFavoritos = async (req, res) => {
    try {
        const produto = await Produto.findById(req.body.idProduto);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Verifica se o produto já está reservado
        if (usuario.reservas.includes(produto._id)) {
            return res.status(400).send('Produto já reservado');
        }

        usuario.reservas.push(produto._id); // Adiciona o ID do produto
        await usuario.save(); // Salva as alterações

        res.status(200).send(usuario.reservas); // Retorna as reservas atualizadas
    } catch (error) {
        console.error('Erro ao adicionar reserva:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.removeReserva = async (req, res) => {
    try {
        const produto = await Produto.findById(req.body.idProduto);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }
        
        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Verifica se o produto já está reservado
        if (usuario.reservas.includes(produto._id)) {
            
            const index=await usuario.reservas.indexOf(produto._id);
            await usuario.reservas.splice(index,1);
            produto.stock++;
            await produto.save();   
            await usuario.save(); // Salva as alterações
        }
        res.status(200).send(usuario.reservas); // Retorna as reservas atualizadas
    } catch (error) {
        console.error('Erro ao remover reserva:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.removeFavoritos = async (req, res) => {
    try {
        const produto = await Produto.findById(req.body.idProduto);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        const usuario = await Usuario.findById(req.usuario.id); // Usa o ID do usuário autenticado
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Verifica se o produto já está reservado
        if (usuario.favoritos.includes(produto._id)) {
            const index=await usuario.favoritos.indexOf(produto._id);
            await usuario.favoritos.splice(index,1);
            await usuario.save(); // Salva as alterações
        }else{
            return res.status(404).send('Este usuario nao favoritou este item');
        }
        res.status(200).send(usuario.reservas); // Retorna as reservas atualizadas
    } catch (error) {
        console.error('Erro ao adicionar reserva:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createUsuario = async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash(req.body.password, 10); // Criptografa a senha
        const user = new Usuario({
            nome: req.body.nome,
            userName: req.body.userName,
            email: req.body.email,
            telefone: req.body.telefone,
            nif: req.body.nif,
            password: hashedPassword, // Usa a senha criptografada
            avaliacoes: [],
            favoritos: [],
            reservas: [],
            banido: false
        });
        await user.save();
        res.status(201).send(user);
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const usuario = await Usuario.findOne({ email });
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Verifica a senha
        const isMatch = await bcrypt.compare(password, usuario.password);
        if (!isMatch) {
            return res.status(400).send('Senha incorreta');
        }

        // Gera o token
        const token = jwt.sign({ id: usuario._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(200).json({ token });
    } catch (error) {
        console.error('Erro ao fazer login:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteUsuario = async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.params.id);
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }

        // Readiciona o estoque de cada produto reservado
        const reservas = usuario.reservas; // Supondo que reservas sejam IDs de produtos
        await Promise.all(reservas.map(async (produtoId) => {
            const produto = await Produto.findById(produtoId);
            if (produto) {
                produto.stock++; // Incrementa o estoque
                await produto.save(); // Salva as alterações
            }
        }));

        // Agora, deleta o usuário
        await Usuario.findByIdAndDelete(req.params.id);
        
        res.status(200).send('Usuário removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover usuário:', error);
        res.status(500).send('Erro no servidor');
    }
};


exports.updateUsuario = async (req, res) => {
    const usuario = await Usuario.findByIdAndUpdate(req.params.id, {
        nome: req.body.nome,
        userName: req.body.userName,
        email: req.body.email,
        telefone: req.body.telefone,
        nif: req.body.nif,
        password: req.body.password,
        avaliacoes: [],
        favoritos: [],
        reservas: [],
        banido: req.body.banido
    }, { new: true });
    
    res.status(200).send(usuario);
};

exports.editarInformacoes = async (req, res) => {
    const usuario = await Usuario.findByIdAndUpdate(req.params.id, {
        userName: req.body.userName,
        email: req.body.email,
        telefone: req.body.telefone,
        });
    
    res.status(200).send(usuario);
};

exports.editarSenha = async (req, res) => {
    const usuario = await Usuario.findById(req.params.id);
    if(usuario.password!==req.body.oldPass)return res.status(500).send('senha antiga errada');
    else usuario.password=req.body.newPass;
    usuario.save();
    
    res.status(200).send(usuario);
};