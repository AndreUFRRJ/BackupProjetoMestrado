//src/controllers/avaliacaoController
const Avaliacao = require('../models/Avaliacao');
const Vendedor = require('../models/Vendedor');
const Usuario = require('../models/Usuario');

exports.getAllAvaliacoes = async (req, res) => {
    try {
        const avaliacoes = await Avaliacao.find();
        res.status(200).send(avaliacoes);
    } catch (error) {
        console.error('Erro ao buscar avaliações:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createAvaliacao = async (req, res) => {
    try {
        const vendedor=await Vendedor.findById(req.body.idVendedor);
        const usuario=await Usuario.findById(req.body.idVendedor);
        
        const avaliacao = new Avaliacao({
            vendedor:vendedor,
            cliente: usuario,
            nota: req.body.nota
        });
        await avaliacao.save();
        await vendedor.avaliacoes.push(avaliacao);
        await vendedor.save();
        await usuario.avaliacoes.push(avaliacao);
        await usuario.save();
        
        res.status(201).send(avaliacao);
    } catch (error) {
        console.error('Erro ao criar avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteAvaliacao = async (req, res) => {
    try {
        const avaliacaoAux=await Avaliacao.findById(req.params.id);
        const avaliacao = await Avaliacao.findByIdAndDelete(req.params.id);
        if (!avaliacao ||!avaliacaoAux) {
            return res.status(404).send('Avaliação não encontrada');
        }
        const usuario=await Usuario.find(avaliacaoAux.usuario);
        const vendedor=await Vendedor.find(avaliacaoAux.vendedor);
        const index = await vendedor.avaliacoes.indexOf(avaliacao);
        await vendedor.avaliacoes.splice(index, 1);
        const indexUsuario=await usuario.avaliacoes.indexOf(avaliacao);
        await usuario.avalicoes.splice(indexUsuario,1);
        await usuario.save();
        await vendedor.save();
        res.status(200).send('Avaliação removida com sucesso');
    } catch (error) {
        console.error('Erro ao remover avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateAvaliacao = async (req, res) => {
    const avaliacao = await Avaliacao.findByIdAndUpdate(req.params.id, {
        nota: req.body.nota
    }, { new: true });
    
    res.status(200).send(avaliacao);
};
