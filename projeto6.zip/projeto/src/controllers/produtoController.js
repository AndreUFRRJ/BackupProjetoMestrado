//src/controller/produtoController

const Produto = require('../models/Produto');
const Usuario = require('../models/Usuario');
const Vendedor = require('../models/Vendedor');

exports.getAllProdutos = async (req, res) => {
    try {
        const produtos = await Produto.find();
        res.status(200).send(produtos);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.getByCategoria = async (req, res) => {
    try {
        const categoria = req.body.categoria;
        if (!categoria) {
            return res.status(400).send('Categoria não fornecida');
        }
        
        const produtos = await Produto.find({ categoria });
        if (produtos.length === 0) {
            return res.status(404).send('Nenhum produto encontrado para essa categoria');
        }

        res.status(200).send(produtos);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createProduto = async (req, res) => {
    try {
        const vendedor = await Vendedor.findById(req.params.vendedorId); // Alterado para vendedorId
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }

        const produto = new Produto({
            nome: req.body.nome,
            categoria: req.body.categoria,
            vendedor: req.params.vendedorId,
            descricao: req.body.descricao,
            precoOriginal: req.body.precoOriginal,
            precoPromocional: req.body.precoPromocional,
            stock: req.body.stock,
            clientesInteressados: [],
            ativo: true,
            destacado: false
        });
        await produto.save();
        vendedor.produtos.push(produto);
        await vendedor.save();

        res.status(201).send(produto);
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteProduto = async (req, res) => {
    try {
        const aux = await Produto.findById(req.params.id);
        if (!aux) {
            return res.status(404).send('Produto não encontrado');
        }

        const vendedor = await Vendedor.findById(aux.vendedor);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }
        usuariosFavoritos = await Usuarios.find(user=>user.favoritos.includes(aux._id));
        usuariosFavoritos.forEach(element => {
            element.favoritos=element.favoritos.filter(produtoId=>!produtoId.equals(aux._id));
        });
        usuariosReservados = await Usuarios.find(user=>user.reservados.includes(aux._id));
        usuariosReservados.forEach(element => {
            element.reservados=element.reservados.filter(produtoId=>!produtoId.equals(aux._id));
        });
        vendedor.produtos = vendedor.produtos.filter(produtoId => !produtoId.equals(aux._id));
        await vendedor.save();

        await Produto.findByIdAndDelete(req.params.id);
        res.status(200).send('Produto removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover produto:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateProduto = async (req, res) => {
    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        produto.nome=req.body.nome;
        produto.descricao=req.body.descricao;
        await produto.save();

        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao atualizar produto:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updatePrecoOriginal = async (req, res) => {
    const { precoOriginal } = req.body;
    if (precoOriginal <= 0) {
        return res.status(400).send('O preço original deve ser maior que 0.');
    }

    try {
        const produto = await Produto.findByIdAndUpdate(req.params.id, {
            precoOriginal: precoOriginal
        }, { new: true });

        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao atualizar preço original:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updatePrecoPromocional = async (req, res) => {
    const { precoPromocional } = req.body;

    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        if (precoPromocional >= produto.precoOriginal) {
            return res.status(400).send('O preço promocional deve ser menor que o preço original.');
        }

        produto.precoPromocional = precoPromocional;
        await produto.save();

        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao atualizar preço promocional:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateStock = async (req, res) => {
    const stockAtual = req.body.stock;
    if (stockAtual < 0) {
        return res.status(400).send("Valor inválido");
    }

    try {
        const produto = await Produto.findByIdAndUpdate(req.params.id, {
            stock: stockAtual
        }, { new: true });

        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao atualizar o estoque:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.indisponivel = async (req, res) => {
    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) {
            return res.status(404).send('Produto não encontrado');
        }

        produto.stock = 0;
        produto.ativo = false;
        await produto.save();

        res.status(200).send(produto);
    } catch (error) {
        console.error('Erro ao marcar produto como indisponível:', error);
        res.status(500).send('Erro no servidor');
    }
};
