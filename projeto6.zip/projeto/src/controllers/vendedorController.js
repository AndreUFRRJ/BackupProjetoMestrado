//src/controllers/vendedorController
const Vendedor = require('../models/Vendedor');
const Produto = require('../models/Produto');

exports.getAllVendedores = async (req, res) => {
    try {
        const vendedores = await Vendedor.find();
        res.status(200).send(vendedores);
    } catch (error) {
        console.error('Erro ao buscar vendedores:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.getById = async (req, res) => {
    const idVendedor = req.params.id; // Alterado para req.params.id
    try {
        const vendedor = await Vendedor.findById(idVendedor);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }
        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao buscar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createVendedor = async (req, res) => {
    try {
        const vendedor = new Vendedor({
            nome: req.body.nome,
            email: req.body.email,
            endereco: req.body.endereco,
            avaliacao: 0,
            password: req.body.password,
            produtos: []
        });
        await vendedor.save();
        res.status(201).send(vendedor);
    } catch (error) {
        console.error('Erro ao criar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteVendedor = async (req, res) => {
    try {
        const vendedorAux = await Vendedor.findById(req.params.id);
        if (!vendedorAux) {
            return res.status(404).send('Vendedor não encontrado');
        }

        // Excluindo produtos do vendedor
        for (const produtoId of vendedorAux.produtos) { // Alterado para vendedorAux.produtos
            await Produto.findByIdAndDelete(produtoId);
        }

        // Excluindo o vendedor
        await Vendedor.findByIdAndDelete(req.params.id);
        res.status(200).send('Vendedor removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateVendedor = async (req, res) => {
    try {
        const vendedor = await Vendedor.findByIdAndUpdate(req.params.id, {
            nome: req.body.nome,
            email: req.body.email,
            endereco: req.body.endereco,
         });

        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }

        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao atualizar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateSenha= async (req, res) => {
    try {
        const vendedor = await Vendedor.findById(req.params.id);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }

        if(vendedor.password!==req.body.oldPass) return res.status(400).send("senha antiga incorreta");
        const novaSenha=req.body.newPass;
        if(novaSenha.length<6) return res.status(400).send("nova senha muito curta");
        vendedor.password=novaSenha;
        vendedor.save();
        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao atualizar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};
exports.updateMasterVendedor = async (req, res) => {
    try {
        const vendedor = await Vendedor.findByIdAndUpdate(req.params.id, {
            nome: req.body.nome,
            email: req.body.email,
            endereco: req.body.endereco,
            avaliacao: req.body.avaliacao,
            password: req.body.password,
            banido: req.body.banido
        }, { new: true });

        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }

        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao atualizar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.atualizaAvaliacao = async (req, res) => {
    try {
        const vendedor = await Vendedor.findByIdAndUpdate(req.params.id);
        let media=0;
        let contador=0;
        vendedor.avaliacoes.forEach(element => {
           contador++;
           media+=element; 
        });
        media/=contador;
        vendedor.avaliacao=media;
        vendedor.save();

        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao atualizar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.destacarProduto= async (req, res) => {
    try {
        const vendedor = await Vendedor.findById(req.params.id);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }
        const produto=vendedor.produtos.indexOf(req.body.idProduto);
        if(!produto) return res.status(404).send('produto não encontrado');
        
        (produto.destacarProduto===true? false : true);
        
        produto.save();
    } catch (error) {
        console.error('Erro ao atualizar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
};
