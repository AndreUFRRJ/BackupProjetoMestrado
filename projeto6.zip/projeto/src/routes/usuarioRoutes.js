// src/routes/usuarioRoutes.js
const express = require('express');
const usuarioController = require('../controllers/usuarioController');

const router = express.Router();

// Rotas de Usuário
router.get('/', usuarioController.getAllUsuarios);
router.post('/', usuarioController.createUsuario);
router.post('/login', usuarioController.login);
router.get('/:id', usuarioController.getUsuarioById);
router.get('/favoritos', usuarioController.getFavoritos);
router.get('/reservas', usuarioController.getReservas);
router.post('/reservas', usuarioController.addReserva);
router.delete('/reservas', usuarioController.removeReserva);
router.post('/favoritos', usuarioController.addFavoritos);
router.delete('/favoritos', usuarioController.removeFavoritos);
router.delete('/usuario', usuarioController.deleteUsuario);
router.put('/:id',usuarioController.updateUsuario);
router.put('/:id',usuarioController.editarInformacoes);
router.put('/:id',usuarioController.editarSenha)

module.exports = router;
