//src/routes/produtoRouters
const express = require('express');
const router = express.Router();
const produtoController = require('../controllers/produtoController');

// Rotas para produtos
router.get('/', produtoController.getAllProdutos);
router.get('/categoria', produtoController.getByCategoria);
router.post('/:vendedorId', produtoController.createProduto); 
router.delete('/:id', produtoController.deleteProduto);
router.put('/:id', produtoController.updateProduto);
router.put('/:id/preco-original', produtoController.updatePrecoOriginal);
router.put('/:id/preco-promocional', produtoController.updatePrecoPromocional);
router.put('/:id/stock', produtoController.updateStock);
router.put('/:id/indisponivel', produtoController.indisponivel);

module.exports = router;
