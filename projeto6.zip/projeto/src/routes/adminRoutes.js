// src/routes/adminRoutes.js
const express = require('express');
const adminController = require('../controllers/adminController');

const router = express.Router();

// Rotas do Admin
router.get('/', adminController.getAllAdmins);
router.post('/', adminController.createAdmin);
router.delete('/:id', adminController.deleteAdmin);
router.put('/:id', adminController.updateAdmin);
router.put('/:id', adminController.banirUsuario);
router.put('/:id', adminController.banirVendedor);
router.put('/:id', adminController.banirProduto);
router.put('/:id', adminController.liberarProduto);
router.put('/:id', adminController.liberarUsuario);
router.put('/:id', adminController.liberarVendedor);
module.exports = router;
