// src/routes/vendedorRoutes.js
const express = require('express');
const Vendedor = require('../models/Vendedor.js');

const router = express.Router();

//GET

router.get("/", async (req, res) => {
    try {
        const vendedor = await Vendedor.find();
        res.status(200).send(vendedor);
    } catch (error) {
        console.error('Erro ao buscar vendedores:', error);
        res.status(500).send('Erro no servidor');
    }
});
//POST
router.post("/", async (req, res) => {
    try {
        const vendedor = new Vendedor({
            nome: req.body.nome,
            email: req.body.email,
            endereco: req.body.endereco,
            avaliacao: 0,
            password: req.body.password,
            produtos: []
        });
        await vendedor.save();
        res.status(201).send(vendedor);
    } catch (error) {
        console.error('Erro ao criar vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
});

//DELETE

router.delete("/:id", async (req, res) => {
    try {
        const vendedor = await Vendedor.findByIdAndDelete(req.params.id);
        if (!vendedor) {
            return res.status(404).send('Vendedor não encontrado');
        }
        res.status(200).send('Vendedor removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover vendedor:', error);
        res.status(500).send('Erro no servidor');
    }
});


//UPDATE


router.put("/:id",async(req,res)=>{
    const vendedor=await Vendedor.findByIdAndUpdate(req.params.id,{
        nome: req.body.nome,
        email: req.body.email,
        endereco: req.body.endereco,
        avaliacao: req.body.avaliacao,
        password: req.body.password,
        produtos: [],
        banido: req.body.banido
            
    },{new:true} );
    res.status(200).send(produto);

});


module.exports = router;
