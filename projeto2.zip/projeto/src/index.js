const express = require('express');
const mongoose = require('mongoose');
const adminRoutes = require('./routes/adminRoutes');
const avaliacaoRoutes = require('./routes/avaliacaoRoutes');
const produtoRoutes = require('./routes/produtoRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');
const vendedorRoutes = require('./routes/vendedorRoutes');

const app = express();
app.use(express.json());
const port = 3000;

mongoose.connect('mongodb://127.0.0.1:27017/PWA')
    .then(() => console.log("Conectado ao MongoDB..."))
    .catch(err => console.error("Erro ao conectar ao MongoDB:", err));

// Usar rotas
app.use('/admin', adminRoutes);
app.use('/avaliacao', avaliacaoRoutes);
app.use('/produto', produtoRoutes);
app.use('/usuario', usuarioRoutes);
app.use('/vendedor', vendedorRoutes);

// Iniciar o servidor
app.listen(port, () => {
    console.log("App rodando...");
});
