// src/models/Vendedor.js
const mongoose = require('mongoose');

const vendedorSchema = new mongoose.Schema({
    nome: String,
    email: String,
    endereco: String,
    avaliacao: Number,
    password: String,
    produtos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    banido: Boolean
});
module.exports = mongoose.model('Vendedor', vendedorSchema);