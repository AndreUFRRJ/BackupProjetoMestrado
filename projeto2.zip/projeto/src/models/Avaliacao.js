//src/ models/Avaliacao.js
const mongoose = require('mongoose');

const avaliacaoSchema = new mongoose.Schema({
    vendedor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' },
    cliente: { type: mongoose.Schema.Types.ObjectId, ref: 'Cliente' },
    nota: Number
});

module.exports = mongoose.model('Avaliacao', avaliacaoSchema);