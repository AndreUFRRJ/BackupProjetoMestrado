//src/ models/Admin.js
const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    nome: String,
    email: String,
    produtosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Produto' }],
    usuariosBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' }],
    vendedoresBloqueados: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendedor' }]
});

module.exports = mongoose.model('Admin', adminSchema);