//src/routes/vendedorRoutes
const express = require('express');
const router = express.Router();
const vendedorController = require('../controllers/vendedorController');

// Rotas para vendedores
router.get('/', vendedorController.getAllVendedores);
router.get('/:id', vendedorController.getById);
router.post('/', vendedorController.createVendedor);
router.delete('/:id', vendedorController.deleteVendedor);
router.put('/:id', vendedorController.updateVendedor);

module.exports = router;
