const express = require('express');
const avaliacaoController = require('../controllers/avaliacaoController');

const router = express.Router();

// GET
router.get('/', avaliacaoController.getAllAvaliacoes);

// POST
router.post('/', avaliacaoController.createAvaliacao);

// DELETE
router.delete('/:id', avaliacaoController.deleteAvaliacao);

// PUT
router.put('/:id', avaliacaoController.updateAvaliacao);

module.exports = router;
