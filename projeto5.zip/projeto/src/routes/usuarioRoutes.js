//src/routes/usuarioRoutes
const express = require('express');
const usuarioController = require('../controllers/usuarioController');

const router = express.Router();

// GET
router.get('/', usuarioController.getAllUsuarios);

// POST
router.post('/', usuarioController.createUsuario);

// DELETE
router.delete('/:id', usuarioController.deleteUsuario);

// PUT
router.put('/:id', usuarioController.updateUsuario);

module.exports = router;
