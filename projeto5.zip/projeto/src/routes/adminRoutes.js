const express = require('express');
const adminController = require('../controllers/adminController');

const router = express.Router();

// GET
router.get('/', adminController.getAllAdmins);

// POST
router.post('/', adminController.createAdmin);

// DELETE
router.delete('/:id', adminController.deleteAdmin);

// PUT
router.put('/:id', adminController.updateAdmin);

module.exports = router;
