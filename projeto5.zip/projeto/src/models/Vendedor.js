//src/models/Vendedor
const mongoose = require('mongoose');

const vendedorSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    endereco: {
        type: String,
        required: true
    },
    avaliacao: {
        type: Number,
        default: 0
    },
    password: {
        type: String,
        required: true
    },
    produtos: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Produto' // Certifique-se que não está redefinindo o modelo Produto
    }]
});

// Previne a sobreposição do modelo
const Vendedor = mongoose.models.Vendedor || mongoose.model('Vendedor', vendedorSchema);

module.exports = Vendedor;
