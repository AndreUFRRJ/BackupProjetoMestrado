const Avaliacao = require('../models/Avaliacao');

exports.getAllAvaliacoes = async (req, res) => {
    try {
        const avaliacoes = await Avaliacao.find();
        res.status(200).send(avaliacoes);
    } catch (error) {
        console.error('Erro ao buscar avaliações:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createAvaliacao = async (req, res) => {
    try {
        const avaliacao = new Avaliacao({
            vendedor: req.body.idVendedor,
            cliente: req.body.idCliente,
            nota: req.body.nota
        });
        await avaliacao.save();
        res.status(201).send(avaliacao);
    } catch (error) {
        console.error('Erro ao criar avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteAvaliacao = async (req, res) => {
    try {
        const avaliacao = await Avaliacao.findByIdAndDelete(req.params.id);
        if (!avaliacao) {
            return res.status(404).send('Avaliação não encontrada');
        }
        res.status(200).send('Avaliação removida com sucesso');
    } catch (error) {
        console.error('Erro ao remover avaliação:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateAvaliacao = async (req, res) => {
    const avaliacao = await Avaliacao.findByIdAndUpdate(req.params.id, {
        vendedor: req.body.idVendedor,
        cliente: req.body.idCliente,
        nota: req.body.nota
    }, { new: true });
    
    res.status(200).send(avaliacao);
};
