//src/controllers/usuarioController
const Usuario = require('../models/Usuario');

exports.getAllUsuarios = async (req, res) => {
    try {
        const usuarios = await Usuario.find();
        res.status(200).send(usuarios);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createUsuario = async (req, res) => {
    try {
        const user = new Usuario({
            nome: req.body.nome,
            userName: req.body.userName,
            email: req.body.email,
            telefone: req.body.telefone,
            nif: req.body.nif,
            password: req.body.password,
            avaliacoes: [],
            favoritos: [],
            reservas: [],
            banido: false
        });
        await user.save();
        res.status(201).send(user);
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteUsuario = async (req, res) => {
    try {
        const usuario = await Usuario.findByIdAndDelete(req.params.id);
        if (!usuario) {
            return res.status(404).send('Usuário não encontrado');
        }
        res.status(200).send('Usuário removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover usuário:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateUsuario = async (req, res) => {
    const usuario = await Usuario.findByIdAndUpdate(req.params.id, {
        nome: req.body.nome,
        userName: req.body.userName,
        email: req.body.email,
        telefone: req.body.telefone,
        nif: req.body.nif,
        password: req.body.password,
        avaliacoes: [],
        favoritos: [],
        reservas: [],
        banido: req.body.banido
    }, { new: true });
    
    res.status(200).send(usuario);
};
