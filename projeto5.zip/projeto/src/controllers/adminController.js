const Admin = require('../models/Admin');

exports.getAllAdmins = async (req, res) => {
    try {
        const admins = await Admin.find();
        res.status(200).send(admins);
    } catch (error) {
        console.error('Erro ao buscar administradores:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.createAdmin = async (req, res) => {
    try {
        const admin = new Admin({
            nome: req.body.nome,
            email: req.body.email,
            produtosBloqueados: [],
            usuariosBloqueados: [],
            vendedoresBloqueados: []
        });
        await admin.save();
        res.status(201).send(admin);
    } catch (error) {
        console.error('Erro ao criar admin:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.deleteAdmin = async (req, res) => {
    try {
        const admin = await Admin.findByIdAndDelete(req.params.id);
        if (!admin) {
            return res.status(404).send('Admin não encontrado');
        }
        res.status(200).send('Admin removido com sucesso');
    } catch (error) {
        console.error('Erro ao remover admin:', error);
        res.status(500).send('Erro no servidor');
    }
};

exports.updateAdmin = async (req, res) => {
    const admin = await Admin.findByIdAndUpdate(req.params.id, {
        nome: req.body.nome,
        email: req.body.email,
        produtosBloqueados: [],
        usuariosBloqueados: [],
        vendedoresBloqueados: []
    }, { new: true });
    
    res.status(200).send(admin);
};
