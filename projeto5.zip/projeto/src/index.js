// src/index.js
const express = require('express');
const connectDB = require('./db'); // Importa a função de conexão
const adminRoutes = require('./routes/adminRoutes');
const avaliacaoRoutes = require('./routes/avaliacaoRoutes');
const produtoRoutes = require('./routes/produtoRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');
const vendedorRoutes = require('./routes/vendedorRoutes');

const app = express();
app.use(express.json());
const port = 3000;

connectDB(); // Chama a função para conectar ao MongoDB

// Usar rotas
app.use('/admin', adminRoutes);
app.use('/avaliacao', avaliacaoRoutes);
app.use('/produto', produtoRoutes);
app.use('/usuario', usuarioRoutes);
app.use('/vendedor', vendedorRoutes);

// Iniciar o servidor
app.listen(port, () => {
    console.log("App rodando...");
});
